/**
 * validate-config — Sanity check the user's config.js
 *
 * Run after editing config/config.js to verify all paths exist and
 * the basic environment is wired correctly.
 *
 * Usage: npm run config:validate
 */

const fs = require('fs');
const path = require('path');

let config;
try {
  config = require('../config/config');
} catch (e) {
  console.error('❌ Could not load config/config.js');
  console.error('   Did you copy config/config.example.js → config/config.js?');
  console.error('   Error:', e.message);
  process.exit(1);
}

let pass = 0, fail = 0, warn = 0;

function check(label, ok, hint) {
  if (ok === 'warn') {
    console.log('⚠ ', label);
    if (hint) console.log('   ', hint);
    warn++;
  } else if (ok) {
    console.log('✓', label);
    pass++;
  } else {
    console.log('✗', label);
    if (hint) console.log('  ', hint);
    fail++;
  }
}

console.log('\nValidating Mycelium Pipeline configuration\n');

// Drive root
check('DRIVE_ROOT exists',
  config.DRIVE_ROOT && fs.existsSync(config.DRIVE_ROOT),
  `Set DRIVE_ROOT to your Drive folder. Currently: ${config.DRIVE_ROOT}`);

// Pipeline subfolders
for (const [name, sub] of Object.entries(config.FOLDERS)) {
  const p = path.join(config.DRIVE_ROOT, sub);
  check(`  ${name}: ${sub}`, fs.existsSync(p), `Missing folder. Create: ${p}`);
}

// Obsidian vault
check('OBSIDIAN_VAULT exists',
  config.OBSIDIAN_VAULT && fs.existsSync(config.OBSIDIAN_VAULT),
  `Set OBSIDIAN_VAULT to your vault path. Currently: ${config.OBSIDIAN_VAULT}`);

// DriveFS DB (for get-reel-ids)
const dbPath = config.DRIVEFS_DB;
check('DriveFS metadata DB found',
  dbPath && fs.existsSync(dbPath),
  `Path tried: ${dbPath}\n   Make sure Google Drive Desktop is installed and DRIVEFS_USER_ID is correct.`);

// F.A.E. project (optional)
if (config.FAE_PROJECT_PATH) {
  check('FAE_PROJECT_PATH exists',
    fs.existsSync(config.FAE_PROJECT_PATH),
    `Set to null if you don't have F.A.E. installed. Currently: ${config.FAE_PROJECT_PATH}`);
} else {
  check('FAE_PROJECT_PATH (optional)', 'warn', 'Not set — update-fae will not work.');
}

// Calendar project (optional)
if (config.CALENDAR_PROJECT_PATH) {
  check('CALENDAR_PROJECT_PATH exists',
    fs.existsSync(config.CALENDAR_PROJECT_PATH),
    `Set to null if you don't have content-calendar installed. Currently: ${config.CALENDAR_PROJECT_PATH}`);
} else {
  check('CALENDAR_PROJECT_PATH (optional)', 'warn', 'Not set — schedule-reels will not work.');
}

// Chime
if (config.CHIME_PATH) {
  check('CHIME_PATH file exists',
    fs.existsSync(config.CHIME_PATH),
    `Set to null to disable. Currently: ${config.CHIME_PATH}`);
} else {
  check('CHIME_PATH (optional)', 'warn', 'No chime configured. Watcher will be silent.');
}

// .env
const envPath = path.join(__dirname, '..', '.env');
if (fs.existsSync(envPath)) {
  check('.env file exists', true);
  const env = fs.readFileSync(envPath, 'utf8');
  check('  ANTHROPIC_API_KEY set', /ANTHROPIC_API_KEY=.+/.test(env), 'Required for Claude Code');
} else {
  check('.env file', 'warn', 'Copy .env.example → .env and fill in keys.');
}

console.log(`\n${pass} passed, ${fail} failed, ${warn} warnings`);
process.exit(fail > 0 ? 1 : 0);
