# Architecture

## Agent Roles

The pipeline splits work across specialised Claude Code instances rather than one monolithic agent. Each instance runs in its own terminal, reads a queue file, and produces output to a shared folder.

| Agent | Account tier | Specialisation |
|-------|-------------|----------------|
| F.R.I.D.A.Y. | Standard | Orchestrator. Talks to the user, monitors the pipeline, routes tasks, runs utility scripts. Does not produce content. |
| A.R.T.H.U.R. | Max (higher context) | Short-form reel production. Takes a source clip and brief, outputs a finished 9:16 mp4. Also handles transcription and asset prep. |
| E.D.I.T.H. | Pro | Long-form video editing + carousel production. Same input/output pattern but for longer cuts and multi-slide image decks. |
| D.U.M-E. | Optional | Re-edit specialist. Takes an already-produced reel and applies specific fixes. Optional — ARTHUR can absorb this role if you don't need a separate instance. |

Why split? Context limits. A single Claude instance can't hold 300 frames of source video frames, a 2000-line transcript, a design system reference, and a conversation history at the same time. Splitting by specialisation keeps each instance's context window focused.

---

## Drive Folder Layout

```
[DRIVE_ROOT]/
├── Input & Raw/           ← raw uploads land here
├── Re-edit/               ← fix pass working copies
├── Submission & Output/
│   ├── reels/             ← finished reels (NN-slug.mp4)
│   ├── carousels/         ← carousel batches (YYYY-MM-DD/carousel_NN/)
│   └── docs/              ← text outputs (optional)
├── References/            ← style refs, audio, voiceover sources
└── Archive/               ← completed work
```

Google Drive is the shared medium. All agents read/write to it via their local sync path. There's no API server, no database, no message broker. The filesystem is the bus.

---

## Signal and Queue File Pattern

Agents communicate through files in the Obsidian vault. F.R.I.D.A.Y. owns this folder; other agents read from it.

**Signal file** (`pipeline-signal.json`): written by the mp4-watcher when a new file appears. F.R.I.D.A.Y. reads it to know something happened.

**Queue files** (`ARTHUR QUEUE - PRODUCTION.md`, `EDITH QUEUE.md`, etc.): plain Markdown written by F.R.I.D.A.Y. Each contains a status header, the current task, and a running log of completed work. Agents read their own queue at the start of every session.

This pattern has no runtime dependencies — no server needs to be running, no ports to open. It works across machines as long as the vault folder is synced (Obsidian Sync, iCloud, OneDrive, etc.).

---

## DriveFS SQLite Trick

When ARTHUR submits a reel to `Submission & Output/reels/`, F.R.I.D.A.Y. needs the file's Google Drive cloud ID to embed in the content calendar so the calendar can link to the actual file.

The Drive API requires OAuth and a GCP project. Instead: Google Drive Desktop maintains a local SQLite database of all synced files including their cloud IDs. `scripts/get-reel-ids.cjs` reads that database directly — no API calls, no OAuth, no rate limits.

The database path: `%LOCALAPPDATA%/Google/DriveFS/[account_id]/metadata_sqlite_db` on Windows, equivalent path on macOS. The file is read-only from outside Google Drive Desktop.

This works as long as Drive Desktop is installed and the files are synced. If a file was just uploaded and hasn't synced yet, it won't appear in the DB yet — wait a minute and re-run.

---

## F.A.E. Dashboard

F.A.E. is a static Astro site. It reads `public/data/pipeline.json` at build time (and via Vercel's CDN at runtime). `update-fae.js` scans the pipeline folders and writes that JSON. Push the F.A.E. repo → Vercel rebuilds → dashboard updates.

F.A.E. shows: reel count, agent status badges, activity feed, input files waiting, carousel batches. It's a read-only view — no admin actions.

---

## Content Calendar

The content calendar is a PWA that reads `data/posts.json`. Each entry is a post slot on a specific date. `schedule-reels.cjs` fills in empty "Reel - TBD" slots with real reel data (title, caption, Drive file ID). Push the calendar repo → Vercel redeploys → schedule updates.

The calendar uses 0-indexed months in its date keys (JavaScript's `Date.getMonth()` is 0-11). See `docs/the-zero-indexed-month-bug.md`.

---

## Instagram Reels and YouTube Shorts

Every reel produced by ARTHUR is the same 9:16 mp4 file. It's uploaded to both Instagram Reels and YouTube Shorts without re-encoding. The `ytShort: true` flag in `posts.json` records this intent — but the actual upload is manual. No platform APIs are used.

---

## What's in this repo vs separate apps

| Component | Where |
|-----------|-------|
| Pipeline scripts (watcher, trigger, schedule, etc.) | This repo |
| Agent CLAUDE.md templates | This repo (`templates/`) |
| F.A.E. dashboard | Separate repo, deploys to Vercel |
| Content calendar PWA | Separate repo, deploys to Vercel |
| Obsidian vault (queue files, signal files) | Your Obsidian vault (not versioned here) |
| Google Drive pipeline folder | Google Drive (not versioned anywhere) |
