# mycelium-pipeline

Multi-agent content production pipeline. F.R.I.D.A.Y. orchestrates; A.R.T.H.U.R. produces short-form reels; E.D.I.T.H. handles long-form video and carousels. Files move through a Google Drive shared folder. A file watcher signals the orchestrator when new content lands. Finished reels are auto-scheduled into a content calendar and surfaced on a live dashboard. This is a working production system, not a tutorial project.

---

## Architecture

```
                        ┌─────────────┐
                        │  F.R.I.D.A.Y │  ← Claude Code (orchestrator)
                        │  (this machine│    talks to user, reads signal,
                        │   or any laptop)   routes tasks, pushes updates
                        └──────┬──────┘
                   ┌───────────┼───────────┐
                   ▼           ▼           ▼
             ┌─────────┐ ┌─────────┐ ┌─────────┐
             │ A.R.T.H.  │ │ E.D.I.T.│ │ D.U.M-E.│
             │  U.R.    │ │   H.   │ │(optional│
             │  reels   │ │long-form│ │ re-edits│
             └────┬─────┘ └────┬────┘ └────┬────┘
                  │            │            │
                  └────────────┼────────────┘
                               ▼
                    ┌──────────────────────┐
                    │    Google Drive       │
                    │  PIPELINE FOLDER      │
                    │  ├── Input & Raw/     │
                    │  ├── Re-edit/         │
                    │  └── Submission &     │
                    │       Output/         │
                    └──────────┬───────────┘
                               │
                 ┌─────────────┴────────────┐
                 ▼                          ▼
          ┌────────────┐          ┌──────────────────┐
          │  F.A.E.    │          │  content-calendar │
          │  Dashboard │          │  (PWA, Vercel)    │
          │  (Astro,   │          │  scheduling +     │
          │   Vercel)  │          │  publishing grid  │
          └────────────┘          └──────────────────┘
```

---

## Quickstart

```bash
git clone https://github.com/[your-org]/mycelium-pipeline.git
cd mycelium-pipeline
npm install
cp config/config.example.js config/config.js   # edit this
cp .env.example .env                            # fill in API keys
npm run config:validate
```

---

## Docs

| File | What it covers |
|------|---------------|
| [SETUP.md](SETUP.md) | Full onboarding — install, configure, test |
| [WORKFLOW.md](WORKFLOW.md) | How a single video flows through end to end |
| [ARCHITECTURE.md](ARCHITECTURE.md) | System design and component roles |
| [LIMITATIONS.md](LIMITATIONS.md) | Known gotchas and workarounds |
| [docs/](docs/) | Individual topics (watchers, Drive, Claude Code, etc.) |
| [templates/](templates/) | CLAUDE.md templates for each agent instance |
