# Installing Claude Code

Claude Code is Anthropic's CLI for running Claude as a coding agent. You need it installed before any of the agent scripts will work.

## Prerequisites

- Node.js v20 or higher — check with `node --version`. Download from https://nodejs.org if needed.
- An Anthropic API key — get one at https://console.anthropic.com

## Install

```bash
npm install -g @anthropic-ai/claude-code
```

On Windows, if npm throws an execution policy error:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

Then retry the install.

## Configure your API key

```bash
# Set it as an environment variable (persists for the current session)
export ANTHROPIC_API_KEY=sk-ant-...

# Or add it to your .env file in this repo
echo ANTHROPIC_API_KEY=sk-ant-... >> .env
```

Claude Code will also prompt you for a key the first time you run it if none is set.

## Verify

```bash
claude
```

You should see the Claude Code prompt. If you get "command not found", your global npm bin directory isn't in PATH — check `npm config get prefix` and add `[prefix]/bin` to your PATH.

## VS Code extension (optional but recommended)

Install the "Claude Code" extension from the VS Code marketplace. It gives you a dedicated sidebar panel so you can run the orchestrator agent without switching terminal windows. Each agent (FRIDAY, ARTHUR, EDITH) can run in its own VS Code window or terminal tab.

## Official docs

https://docs.anthropic.com/en/docs/claude-code

## Common errors

| Error | Cause | Fix |
|-------|-------|-----|
| `TypeError: Object not disposable` | Node.js version too old | Upgrade to v20+ |
| `Execution policy` error | Windows default policy blocks npm scripts | Run `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned` |
| 401 Unauthorized | API key missing or wrong | Check `.env` is UTF-8 (see repo README) |
