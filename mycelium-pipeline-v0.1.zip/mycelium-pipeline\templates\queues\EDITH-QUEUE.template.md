# E.D.I.T.H. — Work Queue
**Status:** [IDLE / ACTIVE — brief description]
**Updated:** [YYYY-MM-DD]

---

## STANDING ORDERS

> Permanent recurring tasks that don't need re-assignment each session.
> Remove this section if you have no standing orders.

- [Example: Generate N carousel decks every Wednesday and Saturday by 5PM]
- [Example: Each deck = 6 content slides + 1 SAMPLE Instagram mockup]

---

## ACTIVE — [TASK NAME] (Assigned [YYYY-MM-DD])

### Context
[What this task is about. Target platform (YouTube / carousel / both). What the source material is.]

### Source
- Input: `[DRIVE_ROOT]/Input & Raw/[filename]`
- Reference: `[DRIVE_ROOT]/References/[relevant file or folder]`

### Task
[Specific edit instructions. For carousels: topic, angle, target audience. For long-form: intro hook, structure, CTA.]

### Output
- Long-form: `[DRIVE_ROOT]/Submission & Output/reels/[slug]-yt.mp4`
- Carousel: `[DRIVE_ROOT]/Submission & Output/carousels/[YYYY-MM-DD]/carousel_NN/`

---

## CAROUSEL STANDING CHECKLIST

Each deck must contain:
- [ ] Slides 1-6: content slides
- [ ] Slide 7: `slide_07_SAMPLE.png` — Instagram mockup (phone frame, IG UI, caption copy below)
- [ ] Caption copy written for each deck

---

## COMPLETED

| Date | Output | Format | Notes |
|------|--------|--------|-------|
| [YYYY-MM-DD] | [filename or folder] | [Reel / Carousel] | [notes] |

---

## GENERAL RULES

- [Example: Captions on every video, synced to speech.]
- [Example: Belief-shifting angle preferred over basic how-to for carousels.]
- [Example: Every clip must be relevant to the speech content — no filler b-roll.]
