# Deploying F.A.E. and the Content Calendar

F.A.E. (the pipeline dashboard) and the content calendar are separate repos that deploy to Vercel. This pipeline repo just writes data files into them. You need both cloned locally.

---

## F.A.E. Dashboard

F.A.E. is an Astro project. It reads `public/data/pipeline.json` and renders a live view of what's in the pipeline — reel count, agent status, activity feed.

### Setup

1. Clone the F.A.E. repo to your machine
2. Set `FAE_PROJECT_PATH` in `config/config.js` to that clone path
3. Run `npm install` inside the F.A.E. repo
4. Deploy to Vercel:
   - Push the F.A.E. repo to GitHub
   - Connect it to Vercel (vercel.com → New Project → import from GitHub)
   - Framework preset: Astro
   - No environment variables needed (data is static JSON)

### Updating the dashboard

Every time you want the dashboard to reflect current pipeline state:

```bash
npm run update:fae
```

This writes a fresh `pipeline.json` into `F.A.E./public/data/`. Then push the F.A.E. repo:

```bash
cd [FAE_PROJECT_PATH]
git add public/data/pipeline.json
git commit -m "pipeline update"
git push
```

Vercel auto-deploys on push. The dashboard refreshes within ~30 seconds.

### Cache-bust

If you add new fields to `pipeline.json` and the dashboard isn't showing them, it may be serving a cached build. Force a redeploy from the Vercel dashboard (Deployments → Redeploy). Vercel caches static assets aggressively — a manual redeploy bypasses the cache.

---

## Content Calendar

The content calendar is a PWA that reads `data/posts.json` and shows a monthly calendar view of scheduled posts with their Drive file IDs.

### Setup

1. Clone the content-calendar repo to your machine
2. Set `CALENDAR_PROJECT_PATH` in `config/config.js` to that clone path
3. Run `npm install` inside the content-calendar repo
4. Deploy to Vercel (same steps as F.A.E.)

### Scheduling reels

After ARTHUR produces a batch of reels and you've run `npm run drive:ids` to get their Google Drive file IDs:

1. Edit the `REELS` array at the top of `scripts/schedule-reels.cjs` — one entry per reel: `['filename.mp4', 'Title', 'Caption']`
2. Run:
   ```bash
   npm run schedule:reels
   # or with a start date:
   node scripts/schedule-reels.cjs --start 2026-3-7
   ```
   Note: date format uses 0-indexed months (see `docs/the-zero-indexed-month-bug.md`)
3. Push the content-calendar repo:
   ```bash
   cd [CALENDAR_PROJECT_PATH]
   git add data/posts.json
   git commit -m "schedule batch"
   git push
   ```

---

## Dependency diagram

```
mycelium-pipeline (this repo)
  └── writes → [FAE_PROJECT_PATH]/public/data/pipeline.json
  └── writes → [CALENDAR_PROJECT_PATH]/data/posts.json

[FAE_PROJECT_PATH]  (separate repo)
  └── deploys → Vercel → your-fae-dashboard.vercel.app

[CALENDAR_PROJECT_PATH]  (separate repo)
  └── deploys → Vercel → your-calendar.vercel.app
```

Neither F.A.E. nor the content calendar is included in this repo. They are standalone projects with their own deployment cycles. This repo only writes into them.
