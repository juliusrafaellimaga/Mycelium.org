/**
 * update-fae — F.A.E. Dashboard Data Updater
 *
 * Scans the pipeline folders and writes live data to pipeline.json
 * inside the F.A.E. Astro project. Push F.A.E. to GitHub → Vercel
 * deploys → dashboard updates.
 *
 * Usage: npm run update:fae
 *
 * Requires config.FAE_PROJECT_PATH to be set.
 */

const fs = require('fs');
const path = require('path');
const config = require('../config/config');

if (!config.FAE_PROJECT_PATH) {
  console.error('config.FAE_PROJECT_PATH is null. Set it to your F.A.E. clone path.');
  process.exit(1);
}

const REELS_DIR     = config.REELS_DIR;
const INPUT_DIR     = config.INPUT_DIR;
const CAROUSELS_DIR = config.CAROUSELS_DIR;
const REEDIT_DIR    = config.REEDIT_DIR;
const OUTPUT_FILE   = path.join(config.FAE_PROJECT_PATH, 'public/data/pipeline.json');

const dataDir = path.dirname(OUTPUT_FILE);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

function listFiles(dir) {
  try { return fs.readdirSync(dir).filter(f => !f.startsWith('.')); }
  catch (e) { return []; }
}

function getFileInfo(dir, filename) {
  try {
    const stats = fs.statSync(path.join(dir, filename));
    return {
      name: filename,
      size: Math.round(stats.size / 1024 / 1024 * 10) / 10,
      modified: stats.mtime.toISOString(),
      ext: path.extname(filename).toLowerCase(),
    };
  } catch (e) {
    return { name: filename, size: 0, modified: new Date().toISOString(), ext: path.extname(filename) };
  }
}

// ── Reels ─────────────────────────────────────────────────────────────
const allReelFiles = listFiles(REELS_DIR);
const reels = allReelFiles.filter(f => f.endsWith('.mp4')).map(f => {
  const info = getFileInfo(REELS_DIR, f);
  let status = 'review';
  if (/^\d{2}[-_]/.test(f)) status = 'production';
  return { ...info, status };
});

const samplePngs = allReelFiles.filter(f => f.endsWith('_SAMPLE.png'));

// ── Input files ───────────────────────────────────────────────────────
const inputFiles = listFiles(INPUT_DIR).map(f => {
  const info = getFileInfo(INPUT_DIR, f);
  const baseName = f.replace(/\.[^.]+$/, '');
  const hasTxt = listFiles(INPUT_DIR).includes(baseName + '.txt');
  return { ...info, hasTxt, isVideo: ['.mp4','.mov','.avi','.mkv'].includes(info.ext) };
});
const inputVideos = inputFiles.filter(f => f.isVideo);

// ── Carousels & re-edits ──────────────────────────────────────────────
const carouselBatches = listFiles(CAROUSELS_DIR).filter(f => {
  try { return fs.statSync(path.join(CAROUSELS_DIR, f)).isDirectory(); }
  catch (e) { return false; }
});
const reeditFiles = listFiles(REEDIT_DIR).filter(f => f.endsWith('.mp4'));

// ── Production status ─────────────────────────────────────────────────
const productionReels = reels.filter(r => /^\d{2}[-_]/.test(r.name));
const arthurStatus = productionReels.length > 0 ? 'working' : 'idle';
const arthurTask = productionReels.length > 0
  ? `Production batch — ${productionReels.length} reels rendered`
  : 'Awaiting assignment';

const edithReels = reels.filter(r => r.name.toLowerCase().includes('edith'));
const edithStatus = edithReels.some(r => /final/i.test(r.name)) ? 'graduated' : 'working';
const edithTask = edithStatus === 'graduated' ? 'Graduated — ready for production' : 'Training in progress';

// ── Activity feed ─────────────────────────────────────────────────────
const allFiles = [
  ...reels.map(r => ({ ...r, source: 'reels' })),
  ...inputFiles.filter(f => f.isVideo).map(f => ({ ...f, source: 'input' })),
];
allFiles.sort((a, b) => new Date(b.modified) - new Date(a.modified));

const activity = allFiles.slice(0, 10).map(f => {
  const time = new Date(f.modified);
  const timeStr = time.toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit' });
  const dateStr = time.toLocaleDateString('en-PH', { month: 'short', day: 'numeric' });
  let agent = 'friday';
  let text = '';
  if (f.source === 'reels') {
    if (f.name.toLowerCase().includes('arthur') || /^\d{2}[-_]/.test(f.name)) {
      agent = 'arthur'; text = `ARTHUR submitted ${f.name}`;
    } else if (f.name.toLowerCase().includes('edith')) {
      agent = 'edith';  text = `EDITH submitted ${f.name}`;
    } else {
      text = `New reel: ${f.name}`;
    }
  } else {
    text = `New input: ${f.name}`;
  }
  return { time: `${dateStr} ${timeStr}`, agent, text };
});

// ── Final pipeline shape ──────────────────────────────────────────────
const pipeline = {
  updatedAt: new Date().toISOString(),
  stats: {
    inputVideos: inputVideos.length,
    reels: reels.length,
    carouselBatches: carouselBatches.length,
    reEdits: reeditFiles.length,
    productionReels: productionReels.length,
    samplePngs: samplePngs.length,
  },
  agents: {
    friday: { status: 'online', task: 'Monitoring pipeline', badge: 'ACTIVE' },
    arthur: {
      status: arthurStatus,
      task: arthurTask,
      badge: arthurStatus === 'working' ? 'WORKING' : 'IDLE',
      progress: productionReels.length,
      target: 10,
    },
    edith: {
      status: edithStatus,
      task: edithTask,
      badge: edithStatus === 'graduated' ? 'GRADUATED' : 'WORKING',
      progress: edithStatus === 'graduated' ? 100 : 50,
      target: 100,
    },
  },
  reels,
  inputFiles: inputVideos.map(f => ({ name: f.name, hasTxt: f.hasTxt, size: f.size })),
  activity,
  carouselFiles: listFiles(CAROUSELS_DIR).map(f => ({ name: f, type: 'carousel' })),
  reeditFiles: listFiles(REEDIT_DIR).filter(f => !f.startsWith('.')).map(f => ({ name: f, type: 'reedit' })),
  pipelineFolders: ['Input & Raw','Submission & Output','Re-edit','References','Archive'].map(f => ({ name: f, type: 'folder' })),
};

fs.writeFileSync(OUTPUT_FILE, JSON.stringify(pipeline, null, 2));
console.log('F.A.E. data updated');
console.log('  Reels:', reels.length, '| Input:', inputVideos.length, '| Carousels:', carouselBatches.length, '| Re-edits:', reeditFiles.length);
console.log('  ARTHUR:', arthurStatus, '(' + productionReels.length + ' production reels)');
console.log('  EDITH:', edithStatus);
console.log('  Output:', OUTPUT_FILE);
