param([string]$Message = "")

# send-to-arthur.ps1 — find a Claude Code / PowerShell window that
# isn't us and paste a message into it via the clipboard.
# Used by trigger-arthur.js. Don't run directly.

if ([string]::IsNullOrEmpty($Message)) {
    Write-Host "Usage: send-to-arthur.ps1 -Message 'your message'"
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms

# Find PowerShell / Claude Code windows
$procs = Get-Process | Where-Object {
    ($_.MainWindowTitle -like '*Claude Code*' -or
     $_.MainWindowTitle -like '*PowerShell*' -or
     $_.MainWindowTitle -like '*pwsh*') -and
    $_.MainWindowHandle -ne 0
}

# Filter out our own process
$myPid = (Get-Process -Id $PID).Parent.Id
$procs = $procs | Where-Object { $_.Id -ne $myPid -and $_.Id -ne $PID }

Write-Host "Found $($procs.Count) PowerShell window(s):"
foreach ($p in $procs) {
    Write-Host "  PID $($p.Id): $($p.MainWindowTitle)"
}

if ($procs.Count -eq 0) {
    Write-Host "No target window found."
    exit 1
}

# Use the most recently activated non-self PowerShell window
$target = $procs | Select-Object -Last 1
Write-Host "Targeting: $($target.MainWindowTitle) (PID $($target.Id))"

$wshell = New-Object -ComObject wscript.shell
$wshell.AppActivate($target.Id) | Out-Null
Start-Sleep -Milliseconds 500

# Paste via clipboard (handles special characters that SendKeys mangles)
Set-Clipboard -Value $Message
Start-Sleep -Milliseconds 200
$wshell.SendKeys('^v')
Start-Sleep -Milliseconds 300
$wshell.SendKeys('{ENTER}')

Write-Host "Message sent."
