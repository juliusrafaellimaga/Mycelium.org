/**
 * fetch-wp-pages — Scrape a WordPress site and cache HTML + CSS locally
 *
 * Uses Puppeteer to visit each page (fully rendered — JS, Elementor
 * counters, lazy images, etc.), collect all stylesheet URLs, and
 * download them into a local output directory. Writes a single JSON
 * cache file that rebuild-site.cjs reads to generate Astro pages.
 *
 * Usage:
 *   node scripts/fetch-wp-pages.cjs
 *   node scripts/fetch-wp-pages.cjs --base https://yoursite.com
 *   node scripts/fetch-wp-pages.cjs --out /path/to/astro/public/wp-css
 *
 * Requires:
 *   npm install puppeteer
 *
 * Config keys used:
 *   WEBSITE_REBUILD_TARGET  — base URL of the WP site (e.g. https://yoursite.com)
 *   WP_OUTPUT_DIR           — where to write downloaded CSS files
 *   ASTRO_PROJECT_PATH      — Astro project root (wp-pages-data.json written here)
 *
 * Limitations:
 *   - Puppeteer must be able to reach the site. Private/local WP installs
 *     need the right network access.
 *   - Does not handle login-gated pages.
 *   - CSS download is best-effort; CDN-hosted fonts (Google Fonts) are
 *     kept as remote links.
 */

const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const config = require('../config/config');

// ── Resolve args / config ─────────────────────────────────────────────
const args = process.argv.slice(2);
let baseUrl = config.WEBSITE_REBUILD_TARGET || null;
let outDir  = config.WP_OUTPUT_DIR || null;

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--base') baseUrl = args[++i];
  if (args[i] === '--out')  outDir  = args[++i];
}

if (!baseUrl) {
  console.error('No base URL. Set config.WEBSITE_REBUILD_TARGET or pass --base https://yoursite.com');
  process.exit(1);
}
if (!outDir) {
  console.error('No output dir. Set config.WP_OUTPUT_DIR or pass --out /path/to/astro/public/wp-css');
  process.exit(1);
}

// Normalise trailing slash
baseUrl = baseUrl.replace(/\/$/, '');

// Standard page slugs — edit this list if the site has different pages
const PAGE_SLUGS = [
  { slug: 'home',      url: baseUrl + '/' },
  { slug: 'about',     url: baseUrl + '/about/' },
  { slug: 'videos',    url: baseUrl + '/videos/' },
  { slug: 'resources', url: baseUrl + '/resources/' },
  { slug: 'courses',   url: baseUrl + '/courses/' },
  { slug: 'events',    url: baseUrl + '/events/' },
  { slug: 'feedback',  url: baseUrl + '/feedback/' },
];

const astroProjPath = config.ASTRO_PROJECT_PATH || null;
const cacheFile = astroProjPath
  ? path.join(astroProjPath, 'wp-pages-data.json')
  : path.join(process.cwd(), 'wp-pages-data.json');

// ── Helpers ──────────────────────────────────────────────────────────
function dl(url) {
  return new Promise((resolve, reject) => {
    const getter = url.startsWith('https') ? https : http;
    getter.get(url, (res) => {
      // Follow one redirect
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return dl(res.headers.location).then(resolve).catch(reject);
      }
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

// ── Main ──────────────────────────────────────────────────────────────
(async () => {
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const browser = await puppeteer.launch({ headless: 'new' });
  const results = {};

  for (const pg of PAGE_SLUGS) {
    console.log('Fetching', pg.slug, '—', pg.url);
    const p = await browser.newPage();
    await p.goto(pg.url, { waitUntil: 'networkidle2', timeout: 60000 });

    // Let Elementor counters/animations settle
    await new Promise(r => setTimeout(r, 3000));

    // Scroll to trigger lazy sections
    await p.evaluate(async () => {
      await new Promise((resolve) => {
        let total = 0;
        const distance = 400;
        const timer = setInterval(() => {
          window.scrollBy(0, distance);
          total += distance;
          if (total >= document.body.scrollHeight) { clearInterval(timer); resolve(); }
        }, 100);
      });
    });

    await new Promise(r => setTimeout(r, 2000));
    await p.evaluate(() => window.scrollTo(0, 0));

    const data = await p.evaluate(() => {
      const sheets = Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(l => l.href);
      const inlineStyles = Array.from(document.querySelectorAll('head style')).map(s => s.textContent).join('\n');

      // Force counter widgets to show final values (Elementor)
      document.querySelectorAll('[data-to-value]').forEach(el => {
        const v = el.getAttribute('data-to-value');
        if (v) el.textContent = v;
      });

      // Force lazy images
      document.querySelectorAll('img[data-src]').forEach(img => {
        img.setAttribute('src', img.getAttribute('data-src'));
      });

      return {
        sheets,
        inlineStyles,
        bodyClass: document.body.className,
        mainHTML: document.body.innerHTML,
        title: document.title,
      };
    });

    results[pg.slug] = data;
    await p.close();
    console.log('  Done:', pg.slug, '(' + data.mainHTML.length + ' chars, ' + data.sheets.length + ' sheets)');
  }

  await browser.close();

  // Download all unique CSS files (skip Google Fonts — keep as links)
  const allSheets = new Set();
  Object.values(results).forEach(r => r.sheets.forEach(s => allSheets.add(s)));
  console.log('\nTotal unique sheets:', allSheets.size);

  const CACHE = {};
  let i = 0;
  for (const url of allSheets) {
    if (url.includes('fonts.googleapis.com')) continue;
    try {
      const css = await dl(url);
      const u = new URL(url);
      const base = u.pathname.split('/').filter(Boolean).slice(-2).join('_').replace(/[^a-z0-9._-]/gi, '_');
      const fname = base + '.css';
      fs.writeFileSync(path.join(outDir, fname), css);
      CACHE[url] = '/wp-css/' + fname;
      i++;
      if (i % 5 === 0) console.log('  downloaded', i);
    } catch (e) { console.log('Failed', url, e.message); }
  }

  console.log('Downloaded', i, 'CSS files');

  fs.writeFileSync(cacheFile, JSON.stringify({ results, cache: CACHE }, null, 2));
  console.log('Saved:', cacheFile);
  console.log('\nNext step: node scripts/rebuild-site.cjs');
})();
