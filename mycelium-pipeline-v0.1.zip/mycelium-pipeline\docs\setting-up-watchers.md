# Setting Up the File Watcher

`scripts/mp4-watcher.cjs` polls two folders for new mp4 files and writes a signal file when something appears. You want this running continuously in the background — not just in a terminal you'll close.

## Why polling and not fs.watch?

Google Drive Desktop's virtual filesystem doesn't reliably fire `fs.watch`/`inotify` events. Files can appear without triggering any event, or trigger multiple spurious events. Polling is slower but stable. The default interval is 10 seconds (`WATCHER_INTERVAL_MS` in config).

## Quick test (manual)

```bash
npm run watch
```

Drop a `.mp4` file into `Input & Raw/` and confirm the watcher logs it. Press Ctrl+C when done.

---

## Running as a background service

### Windows — Task Scheduler

1. Open Task Scheduler (`taskschd.msc`)
2. Click "Create Basic Task"
3. Name it something like "Mycelium Pipeline Watcher"
4. Trigger: "When the computer starts"
5. Action: "Start a program"
   - Program: `node`
   - Arguments: `C:\path\to\mycelium-pipeline\scripts\mp4-watcher.cjs`
   - Start in: `C:\path\to\mycelium-pipeline`
6. Finish. Right-click the task → "Run" to test it immediately.

To redirect output to a log file, use a wrapper `.bat`:

```bat
@echo off
node "C:\path\to\mycelium-pipeline\scripts\mp4-watcher.cjs" >> "C:\path\to\watcher.log" 2>&1
```

And point Task Scheduler at the `.bat` file instead.

To check if it's running:

```powershell
Get-Process node
```

### macOS — launchd

Create `~/Library/LaunchAgents/com.yourname.pipeline-watcher.plist`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.yourname.pipeline-watcher</string>
  <key>ProgramArguments</key>
  <array>
    <string>/usr/local/bin/node</string>
    <string>/path/to/mycelium-pipeline/scripts/mp4-watcher.cjs</string>
  </array>
  <key>WorkingDirectory</key>
  <string>/path/to/mycelium-pipeline</string>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>/tmp/pipeline-watcher.log</string>
  <key>StandardErrorPath</key>
  <string>/tmp/pipeline-watcher.log</string>
</dict>
</plist>
```

Load it:

```bash
launchctl load ~/Library/LaunchAgents/com.yourname.pipeline-watcher.plist
```

Check logs:

```bash
tail -f /tmp/pipeline-watcher.log
```

### macOS — nohup (simpler, no auto-restart)

```bash
nohup node scripts/mp4-watcher.cjs >> /tmp/watcher.log 2>&1 &
echo $! > /tmp/watcher.pid
```

Stop it:

```bash
kill $(cat /tmp/watcher.pid)
```

---

## What the watcher writes

When a new file appears, it writes a JSON signal file at the path in `config.SIGNAL_FILE` (default: `[OBSIDIAN_VAULT]/pipeline-signal.json`):

```json
{
  "time": "2026-04-07T10:00:00.000Z",
  "newReels": ["01-composting.mp4"],
  "newInput": [],
  "read": false
}
```

F.R.I.D.A.Y. reads this and sets `"read": true` after processing.
