# The Zero-Indexed Month Bug

## What it is

JavaScript's `Date.getMonth()` returns 0-11, not 1-12. January = 0, December = 11.

The content calendar was built using `Date.getMonth()` for its date keys. That means **April 7, 2026 is stored as `"2026-3-7"`, not `"2026-4-7"`**.

If you pass a human-readable date to `schedule-reels.cjs` using 1-indexed months, your reels will silently land one month later than you intended. The script won't error — it'll just slot everything into May instead of April.

## How to avoid it

When calling `schedule-reels.cjs` with `--start`, subtract 1 from the month:

```bash
# To start from April 7, 2026:
node scripts/schedule-reels.cjs --start 2026-3-7
#                                              ^ month 3 = April
```

If you don't pass `--start`, the script defaults to today using `Date.getMonth()`, so it's always correct when run on the day you intend to start.

## Where else this matters

Anywhere you manually set or read a date key in `data/posts.json` from the content-calendar repo. The keys look like `"2026-3-7"` for April 7, `"2026-11-1"` for December 1, etc.

When reading the calendar and wondering why a reel appears a month off — check the date key. It's almost certainly this.

## Why it wasn't fixed at the source

Fixing it would require migrating all existing `posts.json` entries and updating the calendar rendering logic simultaneously. That's a breaking change with no urgent payoff. The current system works correctly if you know the convention. This doc is the convention.
