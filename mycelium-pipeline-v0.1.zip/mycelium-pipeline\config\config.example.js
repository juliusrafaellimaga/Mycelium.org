/**
 * Mycelium Pipeline — Configuration
 *
 * Copy this file to `config.js` (in the same folder) and edit the values
 * to match your machine. `config.js` is gitignored so your local paths
 * never end up in commits.
 *
 * Run the validator after editing:
 *   node scripts/validate-config.js
 */

const path = require('path');
const os = require('os');

module.exports = {
  // ── Google Drive root ────────────────────────────────────────────────
  // The folder on your machine where Google Drive Desktop syncs the
  // shared MYCELIUM PIPELINE folder. On Windows this is usually under
  // G:/My Drive/. On macOS it's typically ~/Library/CloudStorage/...
  DRIVE_ROOT: 'G:/My Drive/MYCELIUM PIPELINE',

  // ── Pipeline subfolders (relative to DRIVE_ROOT) ─────────────────────
  // These are the standard subfolders the pipeline expects. If a
  // teammate sets up a fresh Drive, they should mirror this structure
  // exactly so all scripts find the right paths.
  FOLDERS: {
    INPUT:        'Input & Raw',
    REELS_OUT:    'Submission & Output/reels',
    CAROUSELS:    'Submission & Output/carousels',
    REEDIT:       'Re-edit',
    REFERENCES:   'References',
    ARCHIVE:      'Archive',
  },

  // ── Obsidian vault path ──────────────────────────────────────────────
  // Where your FRIDAY queue files, signal files, and CLAUDE.md context
  // live. This is typically the local clone of your Obsidian vault.
  OBSIDIAN_VAULT: 'C:/Users/YourName/Documents/Obsidian Vault',

  // ── FRIDAY queue files ────────────────────────────────────────────────
  // Where FRIDAY writes instructions for ARTHUR and EDITH.
  // These live INSIDE your obsidian vault by convention.
  QUEUES: {
    FRIDAY:  'FRIDAY/FRIDAY_TO_ARTHUR.md',
    ARTHUR:  'FRIDAY/ARTHUR QUEUE - PRODUCTION.md',
    EDITH:   'FRIDAY/EDITH QUEUE.md',
    DUME:    'FRIDAY/DUME QUEUE.md',
  },

  // ── Notification chime ────────────────────────────────────────────────
  // WAV file played when the watcher detects a new submission.
  // Set to null to disable.
  CHIME_PATH: null, // e.g. 'C:/path/to/jarvis-done.wav'

  // ── F.A.E. dashboard project path ─────────────────────────────────────
  // Path to your local clone of the F.A.E. Astro project. The
  // update-fae script writes a fresh pipeline.json into its public/
  // folder so the dashboard can read live data.
  // Leave as null if you don't have F.A.E. installed yet.
  FAE_PROJECT_PATH: null, // e.g. 'C:/Users/YourName/Documents/fae'

  // ── Content calendar project path ─────────────────────────────────────
  // Path to your local clone of the content-calendar PWA.
  // The schedule-reels script writes into its data/posts.json.
  // Leave as null if you don't have content-calendar installed yet.
  CALENDAR_PROJECT_PATH: null, // e.g. 'C:/Users/YourName/Documents/content-calendar'

  // ── Google DriveFS metadata DB ────────────────────────────────────────
  // Local SQLite database maintained by Google Drive Desktop. Used to
  // map filenames → cloud Drive file IDs without needing the Drive API.
  //
  // To find your account ID:
  //   Windows:  ls %LOCALAPPDATA%/Google/DriveFS/
  //   macOS:    ls ~/Library/Application\ Support/Google/DriveFS/
  // Look for a numeric folder name (your Google account ID).
  DRIVEFS_USER_ID: 'YOUR_NUMERIC_ACCOUNT_ID', // replace with the numeric folder name under DriveFS/
  DRIVEFS_DB_PATH: null, // auto-derived if null. Override if non-standard.

  // ── Website rebuild (optional) ────────────────────────────────────────
  // Used by scripts/fetch-wp-pages.cjs and scripts/rebuild-site.cjs when
  // migrating a WordPress site to Astro. Leave as null if not relevant.
  WEBSITE_REBUILD_TARGET: null, // e.g. 'https://yoursite.com'
  WP_OUTPUT_DIR:          null, // e.g. 'C:/path/to/astro/public/wp-css'
  ASTRO_PROJECT_PATH:     null, // e.g. 'C:/Users/YourName/Documents/mysite'

  // ── Watcher polling interval ──────────────────────────────────────────
  // How often (ms) the mp4 watcher checks for new files. 10s default.
  // Don't go lower than 5000 — Google Drive's filesystem is slow.
  WATCHER_INTERVAL_MS: 10000,

  // ── Helpers ──────────────────────────────────────────────────────────
  // Convenience getters that combine the above. Don't edit these.
  get REELS_DIR()       { return path.join(this.DRIVE_ROOT, this.FOLDERS.REELS_OUT); },
  get INPUT_DIR()       { return path.join(this.DRIVE_ROOT, this.FOLDERS.INPUT); },
  get CAROUSELS_DIR()   { return path.join(this.DRIVE_ROOT, this.FOLDERS.CAROUSELS); },
  get REEDIT_DIR()      { return path.join(this.DRIVE_ROOT, this.FOLDERS.REEDIT); },
  get SIGNAL_FILE()     { return path.join(this.OBSIDIAN_VAULT, 'pipeline-signal.json'); },
  get FRIDAY_QUEUE()    { return path.join(this.OBSIDIAN_VAULT, this.QUEUES.FRIDAY); },
  get ARTHUR_QUEUE()    { return path.join(this.OBSIDIAN_VAULT, this.QUEUES.ARTHUR); },
  get EDITH_QUEUE()     { return path.join(this.OBSIDIAN_VAULT, this.QUEUES.EDITH); },
  get DRIVEFS_DB() {
    if (this.DRIVEFS_DB_PATH) return this.DRIVEFS_DB_PATH;
    const platform = os.platform();
    if (platform === 'win32') {
      return path.join(process.env.LOCALAPPDATA || '', 'Google/DriveFS', this.DRIVEFS_USER_ID, 'metadata_sqlite_db');
    }
    if (platform === 'darwin') {
      return path.join(os.homedir(), 'Library/Application Support/Google/DriveFS', this.DRIVEFS_USER_ID, 'metadata_sqlite_db');
    }
    return null;
  },
};
