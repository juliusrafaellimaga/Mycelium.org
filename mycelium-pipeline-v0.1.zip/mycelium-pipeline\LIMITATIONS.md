# Limitations

Known issues, gotchas, and things that could break.

---

## Windows-centric trigger scripts

`trigger-arthur.js` and `trigger-edith.js` use PowerShell's `System.Windows.Forms.SendKeys` to focus the agent's terminal window and paste a message. This only works on Windows, and only when the target terminal is open with a window title containing "PowerShell" or "Claude Code."

**Workaround:** `scripts/trigger-via-file.js` writes a trigger file that the agent can poll for instead. Cross-platform. Requires the agent to check for it at startup.

---

## Google Drive filesystem doesn't support fs.watch

Google Drive Desktop's virtual filesystem (DriveFS on Windows, CloudStorage on macOS) does not reliably fire `fs.watch`/`inotify` events. Files can appear without triggering any event.

The watcher uses polling (`setInterval`) instead. This is stable but introduces up to `WATCHER_INTERVAL_MS` (default 10s) of latency before a new file is detected.

Don't set `WATCHER_INTERVAL_MS` below 5000 — Drive's filesystem is slow and you'll get spurious reads.

---

## DriveFS DB path can change after sign-out/sign-in

The numeric user ID folder under `%LOCALAPPDATA%/Google/DriveFS/` can regenerate if you sign out of Google Drive Desktop and back in. If `get-reel-ids.cjs` suddenly fails with "DB not found," re-check the folder:

```
Windows: ls %LOCALAPPDATA%/Google/DriveFS/
macOS:   ls ~/Library/Application\ Support/Google/DriveFS/
```

Update `DRIVEFS_USER_ID` in `config/config.js` if the number changed.

---

## The 0-indexed month bug in the content calendar

JavaScript's `Date.getMonth()` returns 0-11. The content calendar was built using this for date keys. April 7, 2026 = `"2026-3-7"`, not `"2026-4-7"`.

If you pass a human-readable `--start` date to `schedule-reels.cjs`, subtract 1 from the month. Full details: `docs/the-zero-indexed-month-bug.md`.

---

## SendKeys trigger is fragile and machine-specific

Even on Windows, `trigger-arthur.js` depends on the terminal window being open, being titled correctly, and not having focus on something else at the wrong moment. If the terminal is minimised or the title doesn't match the regex in `send-to-arthur.ps1`, the paste will fail silently or land in the wrong window.

Always verify ARTHUR actually received the trigger before assuming the task was assigned. Check ARTHUR's terminal or the queue file.

---

## No automated posting

There is no Instagram or YouTube API integration. Posting is manual: open the calendar, find the scheduled reel, download the Drive file, upload it. The pipeline ends at "scheduled in calendar."

---

## No automated testing

There are no unit or integration tests. Every change to a script should be manually verified by watching the output on real data. The `npm run config:validate` script checks paths and environment but not script logic.

---

## better-sqlite3 requires a C++ build environment

`better-sqlite3` is a native Node.js module. On Windows, you may need Visual Studio Build Tools:

```bash
npm install --global windows-build-tools
```

Or install Visual Studio Community with the "Desktop development with C++" workload. On macOS, Xcode command line tools are sufficient (`xcode-select --install`).

---

## Remotion render timeouts

When rendering reels with large source video files (100MB+), Remotion's default timeout (28s) is too short. Always pass `--timeout=60000`:

```bash
npx remotion render src/index.ts MyReel out/reel.mp4 --timeout=60000
```

---

## .env encoding on Windows

PowerShell's `echo` and `Out-File` commands save files as UTF-16 LE by default. Node.js reads UTF-8. If your `.env` file was written by PowerShell, the API key will read as garbage and you'll get 401s.

Fix:
```powershell
node -e "require('fs').writeFileSync('.env', 'ANTHROPIC_API_KEY=your-key\n', 'utf8');"
```

Or write it in VS Code, Notepad, or any editor that lets you choose UTF-8 encoding.
