# Setup

Full onboarding for a new team member. Assumes you know JavaScript and Git. Does not assume you've used Claude Code before.

---

## 1. Install prerequisites

**Node.js v20+**
Check: `node --version`
Download: https://nodejs.org (LTS version)

**Git**
Check: `git --version`
Download: https://git-scm.com

**Google Drive Desktop**
Download: https://www.google.com/drive/download/
Sign in with the Google account that has access to the shared pipeline folder. Wait for initial sync to finish.

**Claude Code**
```bash
npm install -g @anthropic-ai/claude-code
```
On Windows, if blocked by execution policy:
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```
Then retry. See [docs/installing-claude-code.md](docs/installing-claude-code.md) for full details.

---

## 2. Clone the repo

```bash
git clone https://github.com/[your-org]/mycelium-pipeline.git
cd mycelium-pipeline
```

---

## 3. Install dependencies

```bash
npm install
```

This installs `better-sqlite3` (for reading the DriveFS database), `dotenv`, and `chokidar`. No build step needed.

---

## 4. Configure paths

```bash
cp config/config.example.js config/config.js
```

Open `config/config.js` and edit:

- `DRIVE_ROOT` — the local path where Google Drive Desktop syncs the pipeline folder. On Windows this is typically `G:/My Drive/[FOLDER NAME]`. Check Google Drive Desktop settings for the exact path.
- `FOLDERS` — leave as-is unless you've renamed the Drive subfolders.
- `OBSIDIAN_VAULT` — path to your local Obsidian vault (or any folder where queue files and signal files will live).
- `DRIVEFS_USER_ID` — your Google account's numeric ID. See [docs/connecting-google-drive.md](docs/connecting-google-drive.md) for how to find it.
- `FAE_PROJECT_PATH` — path to your local F.A.E. clone. Leave as `null` if not set up yet.
- `CALENDAR_PROJECT_PATH` — path to your local content-calendar clone. Leave as `null` if not set up yet.

---

## 5. Configure API keys

```bash
cp .env.example .env
```

Open `.env` and fill in:

```
ANTHROPIC_API_KEY=sk-ant-...   # from console.anthropic.com
FAL_KEY=...                    # from fal.ai/dashboard/keys (optional — only needed for AI video/image gen)
NOTION_API_KEY=...             # from notion.so/my-integrations (optional)
```

**Important on Windows:** Do NOT write the `.env` file using PowerShell's `echo` or `Out-File` commands — they save as UTF-16 and Node can't read it. Use Notepad, VS Code, or:
```powershell
node -e "require('fs').writeFileSync('.env', 'ANTHROPIC_API_KEY=your-key\n', 'utf8');"
```

---

## 6. Validate

```bash
npm run config:validate
```

You should see checkmarks next to `DRIVE_ROOT`, the pipeline subfolders, `OBSIDIAN_VAULT`, and the DriveFS DB. Warnings for optional paths (F.A.E., calendar, chime) are fine.

If any required check fails, fix the path in `config/config.js` and re-run.

---

## 7. Set up the file watcher

Test it manually first:

```bash
npm run watch
```

Drop a `.mp4` file into your `Input & Raw/` folder and confirm the watcher logs it. Press Ctrl+C.

To run the watcher continuously as a background service, see [docs/setting-up-watchers.md](docs/setting-up-watchers.md).

---

## 8. (Optional) Set up F.A.E. and the content calendar

See [docs/deploying-fae-and-calendar.md](docs/deploying-fae-and-calendar.md).

These are separate repos that deploy to Vercel. You can skip them initially and set `FAE_PROJECT_PATH` and `CALENDAR_PROJECT_PATH` to `null`.

---

## 9. (Optional) Set up agent CLAUDE.md files

Each Claude Code instance (F.R.I.D.A.Y., A.R.T.H.U.R., E.D.I.T.H.) reads a `CLAUDE.md` file from its working directory or vault to know its role and standing orders.

Copy the appropriate template and customise:

```
templates/CLAUDE.md.friday.template.md  → your orchestrator's CLAUDE.md
templates/CLAUDE.md.arthur.template.md  → ARTHUR's CLAUDE.md
templates/CLAUDE.md.edith.template.md   → EDITH's CLAUDE.md
```

Fill in your actual paths, format specs, and standing orders.

---

## 10. Test end to end

1. Make sure the watcher is running
2. Drop a `.mp4` file into `Input & Raw/`
3. Confirm `pipeline-signal.json` is written to your Obsidian vault
4. (If F.R.I.D.A.Y. is running) confirm it reads the signal and writes a queue entry

If `pipeline-signal.json` appears, the watcher is working. Everything downstream depends on the agents reading and acting on it.

---

## Common errors

| Error | Fix |
|-------|-----|
| `Cannot find module '../config/config'` | You forgot to copy `config.example.js → config.js` |
| `config.DRIVE_ROOT` path not found | Wrong path in config, or Drive hasn't finished syncing |
| `DriveFS metadata DB not found` | Wrong `DRIVEFS_USER_ID` — see docs/connecting-google-drive.md |
| `.env` reads as garbage | Written as UTF-16 — rewrite using node or a text editor |
| `npm install` fails on `better-sqlite3` | Needs a C++ build tool. On Windows: `npm install --global windows-build-tools` |
