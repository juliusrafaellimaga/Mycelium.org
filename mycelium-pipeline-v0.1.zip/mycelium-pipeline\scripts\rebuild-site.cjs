/**
 * rebuild-site — Convert scraped WordPress data into Astro pages
 *
 * Reads wp-pages-data.json (produced by fetch-wp-pages.cjs) and
 * writes one .astro file per page into the Astro project's src/pages/.
 * Each page imports a BaseLayout that injects the WP stylesheets and
 * inline styles, then renders the scraped HTML via set:html.
 *
 * Usage:
 *   node scripts/rebuild-site.cjs
 *   node scripts/rebuild-site.cjs --cache /path/to/wp-pages-data.json
 *   node scripts/rebuild-site.cjs --astro /path/to/astro-project
 *
 * Config keys used:
 *   ASTRO_PROJECT_PATH  — Astro project root (src/pages/ lives here)
 *
 * Limitations:
 *   - Scraped HTML contains WP/Elementor JS hooks. JS-dependent
 *     interactions (sliders, counters) won't work until you replace
 *     them with native Astro components.
 *   - CSS paths assume the CSS files were downloaded to public/wp-css/.
 *   - This is a migration starting point, not a final build.
 */

const fs = require('fs');
const path = require('path');
const config = require('../config/config');

// ── Resolve args / config ─────────────────────────────────────────────
const args = process.argv.slice(2);
let astroProjPath = config.ASTRO_PROJECT_PATH || null;
let cachePath = null;

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--astro') astroProjPath = args[++i];
  if (args[i] === '--cache') cachePath = args[++i];
}

if (!astroProjPath) {
  console.error('No Astro project path. Set config.ASTRO_PROJECT_PATH or pass --astro /path/to/project');
  process.exit(1);
}

if (!cachePath) {
  cachePath = path.join(astroProjPath, 'wp-pages-data.json');
}

if (!fs.existsSync(cachePath)) {
  console.error('Cache file not found:', cachePath);
  console.error('Run scripts/fetch-wp-pages.cjs first.');
  process.exit(1);
}

const outDir = path.join(astroProjPath, 'src/pages');
if (!fs.existsSync(outDir)) {
  console.error('src/pages/ not found in Astro project:', outDir);
  console.error('Make sure ASTRO_PROJECT_PATH points to an initialised Astro project.');
  process.exit(1);
}

// ── Load cache ────────────────────────────────────────────────────────
const data = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
const cssCache = data.cache || {};

function resolveSheet(url) {
  // Google Fonts stay as external links; everything else gets the local path
  if (url.includes('fonts.googleapis.com')) return url;
  return cssCache[url] || url;
}

function escapeForAstro(str) {
  // Escape characters Astro/JSX would interpret inside template literals
  return str
    .replace(/\\/g, '\\\\')
    .replace(/`/g, '\\`')
    .replace(/\$\{/g, '\\${');
}

// ── Generate pages ────────────────────────────────────────────────────
let count = 0;
Object.entries(data.results).forEach(([slug, page]) => {
  const fileName = slug === 'home' ? 'index.astro' : `${slug}.astro`;
  const title = (page.title || slug).replace(/"/g, '\\"');
  const sheetsArray = JSON.stringify(page.sheets.map(resolveSheet));
  const inlineEsc = escapeForAstro(page.inlineStyles || '');
  const htmlEsc = escapeForAstro(page.mainHTML || '');

  const astroPage = `---
import BaseLayout from '../layouts/BaseLayout.astro';

const stylesheets = ${sheetsArray};
const inlineStyles = \`${inlineEsc}\`;
const pageHTML = \`${htmlEsc}\`;
---

<BaseLayout
  title="${title}"
  stylesheets={stylesheets}
  inlineStyles={inlineStyles}
  bodyClass="${page.bodyClass || ''}"
>
  <Fragment set:html={pageHTML} />
</BaseLayout>
`;

  fs.writeFileSync(path.join(outDir, fileName), astroPage);
  console.log('Built:', fileName, '(' + page.mainHTML.length + ' chars, ' + page.sheets.length + ' sheets)');
  count++;
});

console.log('\nDone. ' + count + ' pages written to', outDir);
console.log('Next step: cd into the Astro project and run `npm run dev` to check.');
