# A.R.T.H.U.R. — Production Queue
**Status:** [IDLE / ACTIVE — brief description]
**Updated:** [YYYY-MM-DD]

---

## STANDING ORDERS

> Permanent recurring tasks that don't need re-assignment each session.
> Remove this section if you have no standing orders.

- [Example: Generate N carousels every Wednesday and Saturday by 5PM]
- [Example: Always check References/EDITING_RULEBOOK.md before starting a new reel]

---

## ACTIVE — [TASK NAME] (Assigned [YYYY-MM-DD])

### Context
[What this task is about. What the source material is. Why it matters to the channel.]

### Source
- Input video: `[DRIVE_ROOT]/Input & Raw/[filename]`
- Reference: `[DRIVE_ROOT]/References/[relevant file]`

### Task
[Specific instructions. Be precise — what to cut, what to include, what to avoid.]

### Output
- File: `[DRIVE_ROOT]/Submission & Output/reels/NN-slug.mp4`
- Naming: `[exact filename expected]`

### Rules for this reel
- [Any task-specific rules that override or extend the defaults in your CLAUDE.md]

---

## COMPLETED

| Date | Reel | Notes |
|------|------|-------|
| [YYYY-MM-DD] | [filename] | [approved / revision needed / etc.] |

---

## GENERAL RULES (copy from your CLAUDE.md or repeat key ones here)

- [Example: No anime or cartoon footage. Ever.]
- [Example: No footage showing chemical use in a positive context.]
- [Example: All stock footage must be real-world and relevant to the speech.]
