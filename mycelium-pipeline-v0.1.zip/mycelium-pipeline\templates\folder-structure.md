# Pipeline Folder Structure

This is the expected layout in your Google Drive shared folder. Every script in this repo assumes this structure. If you rename folders, update `config.FOLDERS` to match.

```
[YOUR PIPELINE FOLDER]/          <- this is config.DRIVE_ROOT
├── Input & Raw/                 <- raw video drops here; watcher detects new files
├── Re-edit/                     <- D.U.M-E. (or ARTHUR) working folder for fix passes
├── Submission & Output/
│   ├── reels/                   <- ARTHUR drops finished reels here (NN-slug.mp4)
│   ├── carousels/               <- carousel batches (YYYY-MM-DD/carousel_NN/)
│   └── docs/                    <- text outputs, scripts, transcripts (optional)
├── References/                  <- visual references, audio files, voiceover sources
│   └── frames/                  <- frame extractions from reference videos (optional)
└── Archive/                     <- completed work moved here after posting
```

## Naming conventions

**Reels:** `NN-short-slug.mp4`
- NN = two-digit sequence number (01, 02, ...)
- slug = 2-4 words describing the content, hyphen-separated, lowercase
- Examples: `01-composting-intro.mp4`, `02-tabi-tabi.mp4`

**Carousel batches:** `YYYY-MM-DD/carousel_NN/`
- One subfolder per posting date
- Each carousel subfolder contains `slide_01.png` through `slide_06.png` + `slide_07_SAMPLE.png`

**Re-edit working copies:** `[original-slug]-reedit.mp4` or `[original-slug]-v2.mp4`

## Why this structure?

- `Input & Raw/` and `Submission & Output/reels/` are the two directories the mp4-watcher polls
- The watcher fires a signal when new files appear in either, so F.R.I.D.A.Y. knows when raw input arrives or when a reel is submitted
- Separating reels and carousels makes it easy for `update-fae.js` to count each type independently
- `References/` is intentionally not watched — it's a static resource folder

## Setting this up for a new team member

1. Create the folder structure above in Google Drive (or your equivalent shared storage)
2. Share it with all agents and with yourself
3. Set `DRIVE_ROOT` in `config/config.js` to the local sync path of the root folder
4. Run `npm run config:validate` to confirm all paths resolve correctly
