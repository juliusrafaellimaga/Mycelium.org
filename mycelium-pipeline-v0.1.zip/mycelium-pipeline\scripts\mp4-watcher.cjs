/**
 * mp4-watcher — Pipeline file watcher
 *
 * Polls the Input/ and reels/ folders for new mp4 files. When something
 * lands, it writes a signal file to the Obsidian vault and (optionally)
 * plays a notification chime.
 *
 * Why polling instead of fs.watch? Google Drive's virtual filesystem
 * doesn't support fs.watch events reliably — chokidar dies after a
 * few hours. Polling is dumb but stable.
 *
 * Usage: npm run watch
 * Stop:  Ctrl+C
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const config = require('../config/config');

const REELS = config.REELS_DIR;
const INPUT = config.INPUT_DIR;
const SIGNAL = config.SIGNAL_FILE;
const CHIME  = config.CHIME_PATH;
const INTERVAL = config.WATCHER_INTERVAL_MS || 10000;

function listMp4(dir) {
  try { return new Set(fs.readdirSync(dir).filter(f => f.endsWith('.mp4'))); }
  catch (e) { console.error('Cannot read', dir, '—', e.message); return new Set(); }
}

let knownReels = listMp4(REELS);
let knownInput = listMp4(INPUT);

console.log('mp4-watcher started');
console.log('  Watching:', REELS, '(' + knownReels.size + ' files)');
console.log('  Watching:', INPUT, '(' + knownInput.size + ' files)');
console.log('  Signal file:', SIGNAL);
console.log('  Chime:', CHIME || '(disabled)');

function playChime() {
  if (!CHIME) return;
  try {
    if (process.platform === 'win32') {
      execSync(`powershell -Command "(New-Object Media.SoundPlayer '${CHIME}').PlaySync()"`, { timeout: 10000 });
    } else if (process.platform === 'darwin') {
      execSync(`afplay "${CHIME}"`, { timeout: 10000 });
    } else {
      execSync(`paplay "${CHIME}"`, { timeout: 10000 });
    }
  } catch (e) { /* chime is best-effort */ }
}

setInterval(() => {
  try {
    const currentReels = listMp4(REELS);
    const currentInput = listMp4(INPUT);
    const newReels = [...currentReels].filter(f => !knownReels.has(f));
    const newInput = [...currentInput].filter(f => !knownInput.has(f));
    if (newReels.length || newInput.length) {
      const signal = {
        time: new Date().toISOString(),
        newReels,
        newInput,
        read: false,
      };
      try {
        fs.mkdirSync(path.dirname(SIGNAL), { recursive: true });
        fs.writeFileSync(SIGNAL, JSON.stringify(signal, null, 2));
      } catch (e) { console.error('Failed to write signal:', e.message); }
      playChime();
      console.log('[' + new Date().toLocaleTimeString() + '] NEW:', [...newReels, ...newInput].join(', '));
    }
    knownReels = currentReels;
    knownInput = currentInput;
  } catch (e) {
    console.error('Watch loop error:', e.message);
  }
}, INTERVAL);

// Keep process alive
setInterval(() => {}, 60000);
