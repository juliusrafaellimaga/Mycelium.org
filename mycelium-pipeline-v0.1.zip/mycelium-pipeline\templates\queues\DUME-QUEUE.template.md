# D.U.M-E. — Re-edit Queue
**Status:** [IDLE / ACTIVE — brief description]
**Updated:** [YYYY-MM-DD]

---

## ROLE

D.U.M-E. handles fix passes on already-produced reels. A.R.T.H.U.R. or E.D.I.T.H. flags a reel for re-edit, F.R.I.D.A.Y. assigns it here with specific notes on what to change.

D.U.M-E. does NOT produce original content. Input always comes from another agent's output.

---

## STANDING ORDERS

> Add any recurring re-edit rules here.
> Example: "Always check audio layering before submitting a fix."

---

## ACTIVE — RE-EDIT: [REEL NAME] (Assigned [YYYY-MM-DD])

### Source
- Original reel: `[DRIVE_ROOT]/Submission & Output/reels/[original filename]`
- Working copy: `[DRIVE_ROOT]/Re-edit/[working filename]`

### What to fix
- [Timestamp] [specific issue] — [what to replace it with]
- [Timestamp] [specific issue] — [what to replace it with]

### What NOT to touch
- [List of segments that are approved and must not be changed]

### Output
- Drop fixed reel back in: `[DRIVE_ROOT]/Submission & Output/reels/[original filename]`
  (overwrite, or use `[slug]-v2.mp4` if version tracking is needed)
- Report to F.R.I.D.A.Y. when done

---

## COMPLETED RE-EDITS

| Date | Reel | Fix | Status |
|------|------|-----|--------|
| [YYYY-MM-DD] | [filename] | [brief description] | [approved / needs another pass] |
