/**
 * trigger-via-file — Cross-platform trigger alternative
 *
 * Instead of pasting into a running terminal window (which is Windows-
 * only and brittle), this script just *writes* the queue message to a
 * known file. The agent (ARTHUR / EDITH / DUME) is expected to poll
 * that file every few seconds and react when it changes.
 *
 * This is the recommended setup for non-Windows machines or for
 * unattended pipelines.
 *
 * Usage:
 *   node scripts/trigger-via-file.js arthur path/to/queue.md
 *   node scripts/trigger-via-file.js edith
 *   node scripts/trigger-via-file.js dume "Read DUME QUEUE.md"
 */

const fs = require('fs');
const path = require('path');
const config = require('../config/config');

const agent = (process.argv[2] || '').toLowerCase();
const arg = process.argv[3];

if (!['arthur','edith','dume','friday'].includes(agent)) {
  console.error('Usage: node scripts/trigger-via-file.js <arthur|edith|dume|friday> [queue-file-or-message]');
  process.exit(1);
}

const queueMap = {
  arthur: config.ARTHUR_QUEUE,
  edith:  config.EDITH_QUEUE,
  dume:   path.join(config.OBSIDIAN_VAULT, 'FRIDAY/DUME QUEUE.md'),
  friday: config.FRIDAY_QUEUE,
};

const queueFile = (arg && arg.endsWith('.md')) ? arg : queueMap[agent];
const customMsg = (arg && !arg.endsWith('.md')) ? arg : null;

const trigger = {
  agent,
  time: new Date().toISOString(),
  queueFile,
  message: customMsg || `This is F.R.I.D.A.Y. Read your queue: ${queueFile}`,
};

const triggerPath = path.join(config.OBSIDIAN_VAULT, `FRIDAY/${agent}_trigger.json`);
fs.mkdirSync(path.dirname(triggerPath), { recursive: true });
fs.writeFileSync(triggerPath, JSON.stringify(trigger, null, 2));

console.log('Trigger written:', triggerPath);
console.log('  Agent:', agent);
console.log('  Queue:', queueFile);
console.log('');
console.log('The target agent should be polling this file. If they are not,');
console.log('check their CLAUDE.md to confirm they have a polling instruction.');
