/**
 * trigger-edith — Send a queue message to EDITH's running terminal
 * Same mechanism as trigger-arthur. See that file for details.
 */

const { execSync } = require('child_process');
const path = require('path');
const config = require('../config/config');

const queueFile = process.argv[2] || config.EDITH_QUEUE;
const message = 'This is F.R.I.D.A.Y. Read your queue: ' + queueFile;

console.log('Triggering EDITH →', queueFile);

if (process.platform !== 'win32') {
  console.error('trigger-edith is Windows-only. Use trigger-via-file.js instead.');
  process.exit(1);
}

const helperScript = path.join(__dirname, 'send-to-arthur.ps1'); // same helper

try {
  const result = execSync(
    `powershell -ExecutionPolicy Bypass -File "${helperScript}" -Message "${message}"`,
    { encoding: 'utf8', timeout: 15000 }
  );
  console.log(result);
} catch (e) {
  console.log('Error:', e.stderr || e.message);
  process.exit(1);
}
