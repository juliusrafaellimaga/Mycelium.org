# Connecting Google Drive

The pipeline uses Google Drive Desktop (not the browser) so files sync to a local path your scripts can read directly. The mp4-watcher, update-fae, and get-reel-ids scripts all need a real filesystem path — they don't talk to the Drive API.

## Install Google Drive Desktop

Download from: https://www.google.com/drive/download/

Sign in with the Google account that has access to the shared pipeline folder.

After signing in, Drive Desktop syncs your files to:
- **Windows:** `G:/My Drive/` (or whichever drive letter was assigned during setup)
- **macOS:** `~/Library/CloudStorage/GoogleDrive-[email]/My Drive/`

The exact path shows up in the Google Drive Desktop settings under "Google Drive streaming location."

## Verify the pipeline folder is visible

Open your file manager and navigate to the Drive root. You should see the pipeline folder (e.g. `MYCELIUM PIPELINE`). If it's not there, someone needs to share it with your account first.

Set `DRIVE_ROOT` in `config/config.js` to the full path of that folder.

## Finding your DriveFS user ID

The `get-reel-ids` script reads Drive file IDs from a local SQLite database that Google Drive Desktop maintains. To find it, you need your Google account's numeric user ID.

**Windows:**
```
%LOCALAPPDATA%\Google\DriveFS\
```
Open this in File Explorer (paste the path into the address bar). You'll see one or more numeric folder names like `105000000000000000000`. That number is your `DRIVEFS_USER_ID`.

**macOS:**
```
~/Library/Application Support/Google/DriveFS/
```
Same — look for the numeric folder.

The full DB path is:
- **Windows:** `%LOCALAPPDATA%\Google\DriveFS\[user_id]\metadata_sqlite_db`
- **macOS:** `~/Library/Application Support/Google/DriveFS/[user_id]/metadata_sqlite_db`

Set `DRIVEFS_USER_ID` in `config/config.js` to your numeric ID. The `DRIVEFS_DB` getter in config derives the full path automatically.

## Verify

```bash
npm run config:validate
```

The "DriveFS metadata DB found" check should pass. If it fails, double-check the user ID and that Google Drive Desktop is signed in and running.

## Notes

- The DriveFS DB path can change if you sign out and back in to Google Drive — the user ID folder may regenerate. Re-run `ls` on the DriveFS directory to find the new one.
- The DB is read-only from our end — we never write to it.
- If you have multiple Google accounts signed into Drive Desktop, there will be multiple numeric folders. Use the one that corresponds to the account with access to the pipeline folder.
