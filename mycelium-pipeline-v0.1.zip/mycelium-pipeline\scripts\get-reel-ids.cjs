/**
 * get-reel-ids — Map filenames → Google Drive cloud file IDs
 *
 * Reads the local Google Drive Desktop SQLite database (no API key
 * needed) to look up cloud_id for each filename. Used by the calendar
 * scheduler so reels can be linked from their Drive thumbnails.
 *
 * Usage:
 *   node scripts/get-reel-ids.cjs file1.mp4 file2.mp4 ...
 *   node scripts/get-reel-ids.cjs                           ← reads from stdin
 *
 * Output: writes reel-drive-ids.json in the current working directory.
 */

const fs = require('fs');
const Database = require('better-sqlite3');
const config = require('../config/config');

const DB_PATH = config.DRIVEFS_DB;
if (!DB_PATH || !fs.existsSync(DB_PATH)) {
  console.error('DriveFS metadata DB not found at:', DB_PATH);
  console.error('Make sure Google Drive Desktop is installed and signed in,');
  console.error('and that config.DRIVEFS_USER_ID matches your account folder.');
  process.exit(1);
}

let targets = process.argv.slice(2);

// If no args, read from stdin (one filename per line)
if (targets.length === 0) {
  try {
    const stdin = fs.readFileSync(0, 'utf8');
    targets = stdin.split('\n').map(s => s.trim()).filter(Boolean);
  } catch (e) { /* no stdin */ }
}

if (targets.length === 0) {
  console.error('Usage: node get-reel-ids.cjs file1.mp4 file2.mp4 ...');
  console.error('   or: ls reels/ | node get-reel-ids.cjs');
  process.exit(1);
}

const db = new Database(DB_PATH, { readonly: true, fileMustExist: true });
const stmt = db.prepare(`
  SELECT i.local_title, i.stable_id, s.cloud_id
  FROM items i
  LEFT JOIN stable_ids s ON i.stable_id = s.stable_id
  WHERE i.local_title = ?
  LIMIT 5
`);

const results = {};
for (const filename of targets) {
  const rows = stmt.all(filename);
  if (rows.length === 0) {
    console.log('NOT FOUND:', filename);
    results[filename] = null;
  } else {
    const best = rows.find(r => r.cloud_id) || rows[0];
    console.log(filename, '→', best.cloud_id || '(no cloud_id)');
    results[filename] = best.cloud_id;
  }
}

fs.writeFileSync('reel-drive-ids.json', JSON.stringify(results, null, 2));
console.log('\nSaved reel-drive-ids.json');
db.close();
