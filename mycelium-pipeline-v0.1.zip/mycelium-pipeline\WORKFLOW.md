# Workflow

How a single video travels through the pipeline, end to end. Concrete example: a new raw clip drops in, becomes a finished reel, gets scheduled.

---

## Sequence

```
1. Raw clip lands in Drive
        │
        ▼
2. mp4-watcher detects it
        │
        ▼
3. Signal file written → Obsidian vault
        │
        ▼
4. F.R.I.D.A.Y. reads signal, decides routing
        │
        ├── short-form → ARTHUR queue
        └── long-form  → EDITH queue
               │
               ▼
5. Agent reads queue, produces reel
               │
               ▼
6. Reel dropped in Submission & Output/reels/
               │
               ▼
7. F.R.I.D.A.Y. runs update-fae → dashboard refreshes
               │
               ▼
8. F.R.I.D.A.Y. runs get-reel-ids → gets Drive file IDs
               │
               ▼
9. F.R.I.D.A.Y. runs schedule-reels → reel slotted into calendar
               │
               ▼
10. Content calendar repo pushed → Vercel deploys
```

---

## Step by step with file paths

### 1. Raw clip lands in Drive

Someone uploads a video file to `[DRIVE_ROOT]/Input & Raw/`. Google Drive Desktop syncs it to the local path.

### 2. Watcher detects it

`mp4-watcher.cjs` polls `Input & Raw/` every 10 seconds. It sees a new file and fires.

### 3. Signal file written

```json
// [OBSIDIAN_VAULT]/pipeline-signal.json
{
  "time": "2026-04-07T10:00:00.000Z",
  "newReels": [],
  "newInput": ["raw-interview-clip.mp4"],
  "read": false
}
```

If a chime path is configured, it plays now.

### 4. F.R.I.D.A.Y. reads signal

F.R.I.D.A.Y. (Claude Code instance, running in its own terminal) reads the signal. It opens the file, sees `"read": false`, and processes the new input. It writes `"read": true` back.

F.R.I.D.A.Y. decides: this is a short clip suitable for a reel → route to ARTHUR.

### 5. Queue entry written + ARTHUR triggered

F.R.I.D.A.Y. appends a new task to:
```
[OBSIDIAN_VAULT]/FRIDAY/ARTHUR QUEUE - PRODUCTION.md
```

Then triggers ARTHUR:
```bash
npm run trigger:arthur
# (Windows) pastes a message into ARTHUR's terminal
# (cross-platform) node scripts/trigger-via-file.js
```

### 6. ARTHUR produces the reel

ARTHUR reads the queue, processes `raw-interview-clip.mp4`, builds the reel in Remotion (or whatever tool), and renders to:

```
[DRIVE_ROOT]/Submission & Output/reels/01-interview-slug.mp4
```

The filename follows `NN-slug.mp4` convention.

### 7. F.R.I.D.A.Y. updates the dashboard

The watcher fires again (new file in `reels/`). F.R.I.D.A.Y. runs:

```bash
npm run update:fae
```

This writes a fresh `pipeline.json` into the F.A.E. project. F.R.I.D.A.Y. commits and pushes the F.A.E. repo:

```bash
cd [FAE_PROJECT_PATH]
git add public/data/pipeline.json && git commit -m "pipeline update" && git push
```

Vercel deploys in ~30 seconds.

### 8. Drive file IDs fetched

```bash
npm run drive:ids
```

`get-reel-ids.cjs` reads the local DriveFS SQLite DB and outputs `reel-drive-ids.json` — a map of `filename → cloud Drive file ID`. The content calendar needs these IDs to link to the actual files.

### 9. Reel scheduled

F.R.I.D.A.Y. edits the `REELS` array in `scripts/schedule-reels.cjs`:

```js
const REELS = [
  ['01-interview-slug.mp4', 'Reel Title', 'Instagram caption copy'],
];
```

Then runs:

```bash
npm run schedule:reels
# or with a start date (remember: 0-indexed months):
node scripts/schedule-reels.cjs --start 2026-3-7
```

This writes the reel into the next open slot in `[CALENDAR_PROJECT_PATH]/data/posts.json`.

### 10. Calendar deployed

```bash
cd [CALENDAR_PROJECT_PATH]
git add data/posts.json
git commit -m "schedule batch"
git push
```

Vercel deploys the updated calendar. The reel shows up on the scheduled date.

---

## What "posting" looks like

The calendar stores the Drive file ID. On posting day, whoever posts manually opens the calendar, clicks the day, gets the Drive link, downloads the file, and uploads to Instagram/YouTube. There is no automated posting in this pipeline — that would require platform API access and approval.
