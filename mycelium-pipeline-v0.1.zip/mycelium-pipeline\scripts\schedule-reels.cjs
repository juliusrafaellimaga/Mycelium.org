/**
 * schedule-reels — Place produced reels into content-calendar slots
 *
 * Reads `reel-drive-ids.json` (produced by get-reel-ids.cjs) and
 * places each reel into the next available "Reel - TBD" slot in
 * the content-calendar's posts.json, starting from a configurable
 * date. Mixes reel categories so you don't end up with 10 of the
 * same kind in a row.
 *
 * IMPORTANT: The content calendar uses **0-indexed months** in its
 * date keys (because it's built off Date.getMonth(), which is 0-11).
 * That means April 7, 2026 is `"2026-3-7"`, NOT `"2026-4-7"`.
 * If you forget this, your reels will silently end up a month later
 * than you intended.
 *
 * Usage:
 *   node scripts/schedule-reels.cjs               ← uses defaults below
 *   node scripts/schedule-reels.cjs --start 2026-3-7
 *
 * Requires config.CALENDAR_PROJECT_PATH to be set.
 */

const fs = require('fs');
const path = require('path');
const config = require('../config/config');

if (!config.CALENDAR_PROJECT_PATH) {
  console.error('config.CALENDAR_PROJECT_PATH is null. Set it to your content-calendar clone path.');
  process.exit(1);
}

const POSTS_PATH = path.join(config.CALENDAR_PROJECT_PATH, 'data/posts.json');
if (!fs.existsSync(POSTS_PATH)) {
  console.error('posts.json not found at', POSTS_PATH);
  process.exit(1);
}

// ── Edit this list to match your batch ────────────────────────────────
// Each entry: [filename, title, description]
// The script will look up cloud_id from reel-drive-ids.json.
const REELS = [
  // Example structure — replace with your batch
  // ['01-some-reel.mp4',          'Title',                  'Caption / description'],
];

// Optional: which positions in REELS should be a different category,
// to break up monotony. e.g. if REELS has 13 entries and food-forest
// reels are at indices 2, 6, 10 — set FOOD_FOREST_INDICES = [2, 6, 10].
// (Pure suggestion. Edit REELS in the order you want them posted.)

// ── Parse args ────────────────────────────────────────────────────────
const args = process.argv.slice(2);
let startKey = null;
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--start') startKey = args[++i];
}

// Default: start from "today" in 0-indexed month format
if (!startKey) {
  const now = new Date();
  startKey = `${now.getFullYear()}-${now.getMonth()}-${now.getDate()}`;
}

const idsPath = path.join(process.cwd(), 'reel-drive-ids.json');
if (!fs.existsSync(idsPath)) {
  console.error('reel-drive-ids.json not found in cwd. Run scripts/get-reel-ids.cjs first.');
  process.exit(1);
}
const IDS = JSON.parse(fs.readFileSync(idsPath, 'utf8'));

if (REELS.length === 0) {
  console.error('REELS list is empty. Edit scripts/schedule-reels.cjs and add your batch.');
  process.exit(1);
}

const posts = JSON.parse(fs.readFileSync(POSTS_PATH, 'utf8'));

// Find unfilled reel slots from startKey onwards
const startStamp = keyToStamp(startKey);
const slots = [];
for (const dateKey of Object.keys(posts).sort(byDateKey)) {
  if (keyToStamp(dateKey) < startStamp) continue;
  posts[dateKey].forEach((post, idx) => {
    if (post.driveFileType === 'video' && (!post.driveFileId || (post.title || '').includes('TBD'))) {
      slots.push({ dateKey, idx });
    }
  });
}

console.log('Unfilled reel slots from', startKey + ':', slots.length);
console.log('Reels to place:', REELS.length);

if (slots.length < REELS.length) {
  console.warn('WARNING: not enough open slots — only first', slots.length, 'will be placed.');
}

const placements = [];
REELS.forEach(([filename, title, description], i) => {
  if (i >= slots.length) return;
  const slot = slots[i];
  const driveFileId = IDS[filename];
  if (!driveFileId) {
    console.warn('Skipping (no Drive ID):', filename);
    return;
  }
  const post = posts[slot.dateKey][slot.idx];
  post.title = title;
  post.description = description;
  post.driveFileId = driveFileId;
  post.driveFileName = filename.replace(/\.mp4$/, '');
  post.driveFileType = 'video';
  post.ytShort = true; // Each reel doubles as a YT Short by convention
  placements.push({ date: slot.dateKey, title });
});

fs.writeFileSync(POSTS_PATH, JSON.stringify(posts, null, 2));
console.log('\nPlacements:');
placements.forEach(p => console.log(' ', p.date, '—', p.title));
console.log('\nUpdated', POSTS_PATH);
console.log('\nNext step: cd to your content-calendar repo and `git add data/posts.json && git commit && git push`.');

// ── Helpers ───────────────────────────────────────────────────────────
function keyToStamp(key) {
  const m = key.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (!m) return 0;
  return Number(m[1]) * 10000 + Number(m[2]) * 100 + Number(m[3]);
}
function byDateKey(a, b) { return keyToStamp(a) - keyToStamp(b); }
