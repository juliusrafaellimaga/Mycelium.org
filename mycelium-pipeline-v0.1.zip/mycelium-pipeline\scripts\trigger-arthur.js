/**
 * trigger-arthur — Send a queue message to ARTHUR's running terminal
 *
 * Uses the SendKeys helper (Windows) to focus ARTHUR's PowerShell
 * window and paste a "read your queue" message into it. ARTHUR is
 * a Claude Code instance running in a separate terminal.
 *
 * Usage:
 *   node scripts/trigger-arthur.js                      ← uses default queue
 *   node scripts/trigger-arthur.js path/to/queue.md     ← override
 *
 * Limitations:
 *   - Windows only (uses PowerShell + System.Windows.Forms.SendKeys).
 *   - Requires ARTHUR's terminal window to be open and titled
 *     something matching '*Claude Code*' or '*PowerShell*'.
 *   - Cross-platform replacement: see scripts/trigger-via-file.js
 *     which uses a queue file ARTHUR polls instead.
 */

const { execSync } = require('child_process');
const path = require('path');
const config = require('../config/config');

const queueFile = process.argv[2] || config.ARTHUR_QUEUE;
const message = 'This is F.R.I.D.A.Y. Read your queue: ' + queueFile;

console.log('Triggering ARTHUR →', queueFile);

if (process.platform !== 'win32') {
  console.error('trigger-arthur is Windows-only. Use trigger-via-file.js instead.');
  process.exit(1);
}

const helperScript = path.join(__dirname, 'send-to-arthur.ps1');

try {
  const result = execSync(
    `powershell -ExecutionPolicy Bypass -File "${helperScript}" -Message "${message}"`,
    { encoding: 'utf8', timeout: 15000 }
  );
  console.log(result);
} catch (e) {
  console.log('SendKeys output:', e.stdout || '');
  console.log('Error:', e.stderr || e.message);
  process.exit(1);
}
